package tankwar;

public enum Direction {
    UP,LEFT,RIGHT,DOWN
}
