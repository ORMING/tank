package tankwar;

import com.sun.deploy.net.MessageHeader;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

public class GamePanel extends JFrame {

    /** 定义双缓存图片 */
    Image offScreenImage = null;
    //游戏状态 0未开始 1运行中 2暂停 3失败 4成功
    int state= 0;
    //临时变量
    int a = 1;
    //重绘次数
    int count = 0;
    //窗口长宽
    int width = 800;
    int height = 610;
    //
    List<Bullet> bulletList = new ArrayList<>();
    List<Bot> botList = new ArrayList<>();
    //背景图片
    Image background = Toolkit.getDefaultToolkit().getImage("images/background.jpg");
    Image select = Toolkit.getDefaultToolkit().getImage("images/selecttank.gif");
    int y = 150;
    Tank tank = new Tank("images/player1/p1tankU.gif", 125, 510,40, 30, 15, Direction.UP, TankType.PLAYER1, this);
    Bot bot = new Bot("images/enemy/enemy1U.gif", 125, 110,40, 30, 7, Direction.UP, TankType.BOT, this);
    private int ennemyCount = 0;


    //窗口的启动方法
    public void launch(){
        //标题
        setTitle("坦克大战");
        //窗口初始大小
        setSize(width, height);
        //用户不能调整大小
        setResizable(false);
        //使窗口可见
        setVisible(true);
        //获取屏幕分辨率，使窗口生成时居中
        Toolkit tool = Toolkit.getDefaultToolkit();
        Dimension d = tool.getScreenSize();
        setLocation((d.width - getWidth()) / 2, (d.height - getHeight()) / 2);


        this.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                //super.keyPressed(e);
                int key = e.getKeyCode();
                switch (key){
                    case KeyEvent.VK_W:
                        y = 150;
                        a = 1;
                        repaint();
                        break;
                    case KeyEvent.VK_S:
                        y = 250;
                        a = 2;
                        repaint();
                        break;
                    case KeyEvent.VK_ENTER:
                        state = a;
                        repaint();
                        break;
                    default:
                        break;
                }
            }
        });

        while (true){
            if (count % 100 == 1) {
                botList.add(new Bot("images/enemy/enemy1U.gif", 125, 110,40, 30, 7, Direction.UP, TankType.BOT, this));
                System.out.println("bot:"+botList.size());
                ennemyCount++;
                //System.out.println("bot: " + botList.size());
            }
            repaint();
            try {
                //线程休眠  1秒 = 1000毫秒
                Thread.sleep(25);
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    @Override
    public void paint(Graphics g) {
        //创建和容器一样大小的Image图片
        if(offScreenImage ==null){
            offScreenImage=this.createImage(width, height);
        }
        //获得该图片的画布
        Graphics gImage= offScreenImage.getGraphics();
        //填充整个画布
        gImage.fillRect(0, 0, width, height);
        if(state == 0){
            //添加背景
            gImage.drawImage(background,0,0,null);
            //挂变画笔颜色
            gImage.setColor(Color.BLUE);
            //改变文字大小和样式
            gImage.setFont(new Font("仿宋",Font.BOLD,50));
            //添加文字
            gImage.drawString("选择游戏模式",220,100);
            gImage.drawString("单人游戏",220,200);
            gImage.drawString("双人游戏",220,300);
            gImage.drawImage(select,160,y,null);
        }
        else if(state == 1||state == 2){
            gImage.drawImage(background,0,0,null);
            //改变画笔的颜色
            gImage.setColor(Color.BLUE);
            //改变文字大小和样式
            gImage.setFont(new Font("仿宋",Font.BOLD,50));
            //添加文字
            gImage.drawString("游戏开始",220,300);
            tank.paintSelf(gImage);
            for(Bullet bullet: bulletList){
                bullet.paintSelf(gImage);
            }
            for(Bot bot: botList){
                bot.paintSelf(gImage);
            }
            if(state == 1){
                gImage.drawString("单人模式",220,200);
            }
            else{
                gImage.drawString("双人模式",220,200);
            }
            //重绘次数+1
            count++;
        }
        /** 将缓冲区绘制好哦的图形整个绘制到容器的画布中 */
        g.drawImage(offScreenImage, 0, 0, null);
    }

    public static void main(String[] args) {
        GamePanel gamePanel = new GamePanel();
        gamePanel.launch();
    }
}