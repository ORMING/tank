package tankwar;

public enum TankType {
    PLAYER1,PLAYER2,BOT
}
