package tankwar;

import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Tank extends GameObject{

    private boolean attackCoolDown =true;//攻击冷却状态
    private int attackCoolDownTime =1000;//攻击冷却时间毫秒间隔500ms发射子弹
    TankType tankType;//坦克类型(PLAYER1， PLAYER2, BOT)
    private String upImage; //向上移动时的图片
    private String downImage;//向下移动时的图片
    private String rightImage;//向右移动时的图片
    private String leftImage;//向左移动时的图片
    //坦克size
    int width = 40;
    int height = 50;
    //坦克头部坐标
    Point p;

    //坦克坐标，方向，图片，类型（好，坏），面板（哪个关卡）
    public Tank(String img, int x, int y, int width, int height, int speed, Direction direction, TankType tankType, GamePanel gamePanel) {
        super(img, x,  y, width, height, speed, direction, tankType, gamePanel);
        //不同类型坦克图片
        switch(tankType){
            case PLAYER1:
                upImage = "images/player1/p1tankU.gif";
                downImage = "images/player1/p1tankD.gif";
                leftImage = "images/player1/p1tankL.gif";
                rightImage = "images/player1/p1tankR.gif";
                break;
            case PLAYER2:
                upImage = "images/player2/p2tankU.gif";
                downImage = "images/player2/p2tankD.gif";
                leftImage = "images/player2/p2tankL.gif";
                rightImage = "images/player2/p2tankR.gif";
                break;
            case BOT:
                upImage = "images/enemy/enemy1U.gif";
                downImage = "images/enemy/enemy1D.gif";
                leftImage = "images/enemy/enemy1L.gif";
                rightImage = "images/enemy/enemy1R.gif";
                break;
            default:
                break;
        }
    }

    public void leftward(){
        direction = Direction.LEFT;
        setImg(leftImage);
        this.x -= speed;
    }
    public void rightward(){
        direction = Direction.RIGHT;
        setImg(rightImage);
        this.x += speed;
    }
    public void upward(){
        direction = Direction.UP;
        setImg(upImage);
        this.y -= speed;
    }
    public void downward(){
        direction = Direction.DOWN;
        setImg(downImage);
        this.y += speed;
    }
    public void attack(){
        Point p = getHeadPoint();
        if(attackCoolDown){
            Bullet bullet = new Bullet("images/bullet/bulletGreen.gif",p.x,p.y,10,10,speed,direction,TankType.PLAYER1,gamePanel);
            this.gamePanel.bulletList.add(bullet);
            attackCoolDown = false;
            new AttackCD().start();
        }
    }
    public class AttackCD extends Thread{
        public void run(){
            attackCoolDown=false;//将攻击功能设置为冷却状态
            try{
                Thread.sleep(attackCoolDownTime);//休眠3秒
            }catch(InterruptedException e){
                e.printStackTrace();
            }
            attackCoolDown=true;//将攻击功能解除冷却状态
            this.stop();
        }
    }

    //根据方向确定头部位置，x和y是左下角的点
    public Point getHeadPoint(){
        switch (direction){
            case UP:
                return new Point(x + width/2, y );
            case LEFT:
                return new Point(x, y + height/2);
            case DOWN:
                return new Point(x + width/2, y + height);
            case RIGHT:
                return new Point(x + width, y + height/2);
            default:
                return null;
        }
    }

    @Override
    public void paintSelf(Graphics g) {
        g.drawImage(img, x, y, null);
        if(this.gamePanel.count == 1){
            new AttackCD();
            this.gamePanel.addKeyListener(new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent e){
                    int key = e.getKeyCode();
                    switch (key){
                        case KeyEvent.VK_A:
                            leftward();
                            break;
                        case KeyEvent.VK_S:
                            downward();
                            break;
                        case KeyEvent.VK_D:
                            rightward();
                            break;
                        case KeyEvent.VK_W:
                            upward();
                            break;
                        case KeyEvent.VK_SPACE:
                            attack();
                            break;
                        default:
                            break;
                    }
                }
            });
        }
    }

    @Override
    public Rectangle getRec() {
        return new Rectangle(x, y, width, height);
    }
}
