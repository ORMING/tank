package tankwar;

import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Tank extends GameObject{

    Direction direction = Direction.UP; //移动方向(UP,LEFT,RIGHT,DOWN)初始方向默认向上
    private boolean attackCoolDown =true;//攻击冷却状态
    private int attackCoolDownTime =1000;//攻击冷却时间毫秒间隔500ms发射子弹
    TankType tankType;//坦克类型(PLAYER1， PLAYER2, BOT)
    private String upImage; //向上移动时的图片
    private String downImage;//向下移动时的图片
    private String rightImage;//向右移动时的图片
    private String leftImage;//向左移动时的图片
    //坦克size
    int width = 40;
    int height = 50;
    //坦克头部坐标
    Point p;

    //坦克坐标，方向，图片，类型（好，坏），面板（哪个关卡）
    public Tank(String img, int x, int y, int width, int height, int speed, Direction direction, TankType tankType, GamePanel gamePanel) {
        super(img, x,  y, width, height, speed, direction, tankType, gamePanel);
        //不同类型坦克图片
        switch(tankType){
            case PLAYER1:
                upImage = "images/player1/p1tankU.gif";
                downImage = "images/player1/p1tankD.gif";
                leftImage = "images/player1/p1tankL.gif";
                rightImage = "images/player1/p1tankR.gif";
                break;
            case PLAYER2:
                upImage = "images/player2/p2tankU.gif";
                downImage = "images/player2/p2tankD.gif";
                leftImage = "images/player2/p2tankL.gif";
                rightImage = "images/player2/p2tankR.gif";
                break;
            case BOT:
                upImage = "images/enemy/enemy1U.gif";
                downImage = "images/enemy/enemy1D.gif";
                leftImage = "images/enemy/enemy1L.gif";
                rightImage = "images/enemy/enemy1R.gif";
                break;
            default:
                break;
        }
    }

    public void leftward(){
        direction = Direction.LEFT;
        setImg(leftImage);
        this.x -= speed;
    }
    public void rightward(){
        direction = Direction.RIGHT;
        setImg(rightImage);
        this.x += speed;
    }
    public void upward(){
        direction = Direction.UP;
        setImg(upImage);
        this.y -= speed;
    }
    public void downward(){
        direction = Direction.DOWN;
        setImg(downImage);
        this.y += speed;
    }

    @Override
    public void paintSelf(Graphics g) {
        g.drawImage(img, x, y, null);
        this.gamePanel.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e){
                int key = e.getKeyCode();
                switch (key){
                    case KeyEvent.VK_A:
                        leftward();
                        System.out.println(x+" "+y);
                        break;
                    case KeyEvent.VK_S:
                        downward();
                        System.out.println(x+" "+y);
                        break;
                    case KeyEvent.VK_D:
                        rightward();
                        System.out.println(x+" "+y);
                        break;
                    case KeyEvent.VK_W:
                        upward();
                        System.out.println(x+" "+y);
                        break;
                    default:
                        break;
                }
            }


        });
    }

    @Override
    public Rectangle getRec() {
        return new Rectangle(x, y, width, height);
    }
}
