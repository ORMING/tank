package tankwar;

import java.awt.*;
import java.util.List;

public class Bullet extends GameObject{
    public Bullet(String img, int x, int y, int width, int height, int speed, Direction direction, TankType tankType, GamePanel gamePanel) {
        super(img, x,  y, width, height, speed, direction, tankType, gamePanel);
    }

    public void go(){
        switch (direction){
            case UP:
                upward();
                break;
            case LEFT:
                leftward();
                break;
            case DOWN:
                downward();
                break;
            case RIGHT:
                rightward();
                break;
        }
        //碰撞检测
        hitTank(x, y);
    }

    public void leftward(){
            x -= speed;
    }
    public void rightward(){
            x += speed;
    }
    public void upward(){
            y -= speed;
    }
    public void downward(){
            y += speed;
    }

    public void hitTank(int x, int y){
        Rectangle next=new Rectangle(x,y,width,height);//创建该子弹移动后的目标区域
        java.util.List<Tank> tanks = this.gamePanel.tankList;
        List<Bot> bots = this.gamePanel.botList;
        for(Tank tank: tanks){
            //子弹和坦克
            if(tank.getRec().intersects(next)){
                if(tankType.equals(TankType.BOT)){
                    System.out.println("hit tank");
                    this.gamePanel.tankList.remove(tank);
                    this.gamePanel.bulletList.remove(this);
                }
            }
        }
        //子弹和电脑bot
        for(Bot bot: bots){
            if(bot.getRec().intersects(next)){
                if(!tankType.equals(TankType.BOT)){
                    System.out.println("hit bot");
                    this.gamePanel.botList.remove(bot);
                    this.gamePanel.bulletList.remove(this);
                }
            }
        }
    }

    @Override
    public void paintSelf(Graphics g) {
        g.drawImage(img, x, y, null);
        go();
    }

    @Override
    public Rectangle getRec() {
        return new Rectangle(x, y, width, height);
    }
}
